/*const carregaProdutos = async () => {
    const bolas = await fetch("https://fakestoreapi.com/products/1");
    const a = await bolas.json();
}

carregaProdutos();*/

const $id = (id) => document.getElementById(id);
const $create = (tag) => document.createElement(tag);

async function loadAPI(api) {
    return await (await fetch(api)).json();
}

const root = $id("root");

// #CategoryDiv
const categoryDiv = $create("div");
categoryDiv.id = "categoryDiv";
root.appendChild(categoryDiv);

// #TitleDiv
const titleDiv = $create("div");
titleDiv.id = "TitleDiv";
titleDiv.innerText = "Categorias de produtos";
categoryDiv.appendChild(titleDiv);

// #CategoryList
const ul = $create("ul");
ul.id = "CategoryList";
categoryDiv.appendChild(ul);

async function loadItems() {
    ul.innerHTML = "";
    const categories = await loadAPI("https:/api.escuelajs.co/api/v1/categories");
    for (let i = 0; i < 5; i++) {
        const item = categories[i];

        // .categoryItem
        const li = $create("li");
        li.classList.add("categoryItem");
        ul.appendChild(li);

        // button
        const button = $create("button");
        li.appendChild(button);
        button.addEventListener("click", () => {
            loadCategory(item);
        })

        // div
        const div = $create("div");
        div.innerText = item.name;
        button.appendChild(div);

        // img
        const image = $create("img");
        image.src = item.image;
        button.appendChild(image);
    }
}

async function loadCategory(category) {
    ul.innerHTML = "";

    const backBtn = $create("button");
    backBtn.innerText = "Voltar";
    backBtn.addEventListener("click", loadItems);
    ul.appendChild(backBtn);

    const products = await loadAPI("https:/api.escuelajs.co/api/v1/products?categoryId="+category.id);
    console.log(products);
    for (const item of products) {
        const li = $create("li");
        li.innerText = `Título: ${item.title} Preço: ${item.price}\nDescrição: ${item.description}`;
        ul.appendChild(li);

        const image = $create("img");
        image.src = item.images;
        image.style.width = "50px";
        li.appendChild(image);
    }
}

loadItems();