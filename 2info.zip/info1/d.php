<?php
$somaProdutos = $_GET["altura"]*$_GET["largura"];
echo "A área do retângulo é {$somaProdutos}";