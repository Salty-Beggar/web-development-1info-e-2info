<?php
$troco = $_GET["valorDado"]-$_GET["valorCompra"];
echo "O troco é {$troco}.";