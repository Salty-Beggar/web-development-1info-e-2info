<?php
$somaProdutos = $_GET["produto1"]+$_GET["produto2"]+$_GET["produto3"]+$_GET["produto4"]+$_GET["produto5"];
echo "A soma dos produtos é {$somaProdutos}";