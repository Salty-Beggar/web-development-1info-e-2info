<?php
$somaProdutos = $_GET["valor"]*0.93;
echo "O valor do produto com desconto é {$somaProdutos}";