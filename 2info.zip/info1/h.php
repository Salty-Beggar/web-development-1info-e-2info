<?php
$somaProdutos = $_GET["altura"]*$_GET["largura"]*$_GET["largura2"];
$somaProdutos2 = $somaProdutos*1.03;
echo "O valor de toda a estadia será {$somaProdutos}, e com um imposto de 3% será {$somaProdutos2}.";