<?php
// O require dá fatal error se não acha o arquivo, enquano o include só não faz nada se não acha o arquivo.
require("head.php");
require("menu.php");
require("conteudo.php");
require("foot.php");