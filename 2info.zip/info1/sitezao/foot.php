<?php
echo '</body>
</html>';