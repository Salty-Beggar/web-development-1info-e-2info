<?php
echo '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aaaaaaaaaaaaa</title>
</head>
<body>
    <form method="get" action="register.php">
        <input type="text" name="author" placeholder="Autor">
        <input type="text" name="message" placeholder="Mensagem">
        <button type="submit">Submeter</button>
    </form>
    </body>
    <ul id="List">';