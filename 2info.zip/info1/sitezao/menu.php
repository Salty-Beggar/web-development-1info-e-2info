<?php
echo '<div id="Title">Hazbin Hotel</div>
<nav>
    <button>Onde ver</button>
    <button>Personagens</button>
    <button>Redes sociais</button>
</nav>';