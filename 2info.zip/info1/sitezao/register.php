<?php
$file = file_get_contents("messages.txt");
if (empty($file)) $file = [];
else json_decode($file);
$file[] = [$_GET["author"], date("d"), $_GET["message"]];
file_put_contents("messages.txt", json_encode($file));
header("location:index.html");
die;