<?php
$somaProdutos = $_GET["altura"]*$_GET["largura"];
echo "O valor da diária será {$somaProdutos}";