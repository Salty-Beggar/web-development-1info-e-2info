<?php
$sucessor = $_GET["numero"]+1;
$antecessor = $_GET["numero"]-1;
echo "O sucessor é {$sucessor} e o antecessor {$antecessor}";