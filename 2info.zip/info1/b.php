<?php
echo "Nome: {$_GET["nome"]}<br>";
echo "Ebdereço: {$_GET["endereco"]}<br>";
echo "Telefone: {$_GET["telefone"]}<br>";
echo "Profissão: {$_GET["profissao"]}";