<?php
echo "<select>";

$frutas = ["Abacaxi", "Morango", "Cebola"];

foreach ($frutas as $f) {
    echo "<option>{$f}</option>     ";
}


echo "</select>";