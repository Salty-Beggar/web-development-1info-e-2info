package EstudoProgamacao;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader b = new BufferedReader(new InputStreamReader(System.in));
        
        String[] curLine = b.readLine().split(" ");
        int n = Integer.parseInt(curLine[0]);
        int m = Integer.parseInt(curLine[1]);
        int k = Integer.parseInt(curLine[2]);
        
        ArrayList<ArrayList<Integer[]>> adjList = new ArrayList<>();
        for (int i = 0; i < n; i++)
            adjList.add(new ArrayList<>());
        
        for (int i = 0; i < m; i++) {
            curLine = b.readLine().split(" ");
            int u = Integer.parseInt(curLine[0])-1;
            int v = Integer.parseInt(curLine[1])-1;
            int w = Integer.parseInt(curLine[2]);
            adjList.get(u).add(
                new Integer[]{v, w}
            );
            adjList.get(v).add(
                new Integer[]{u, w}
            );
        }
        
        int[][] courierRoutes = new int[k][2];
        for (int i = 0; i < k; i++) {
            curLine = b.readLine().split(" ");
            int u = Integer.parseInt(curLine[0])-1;
            int v = Integer.parseInt(curLine[1])-1;
            courierRoutes[i] = new int[]{i, v};
        }
        
        System.out.println();
    }
    
    public static int minCostCourierRoutes(int n, ArrayList<ArrayList<Integer>> adjList, int k, int[][] courierRoutes) {
        int[][] _cR = courierRoutes;
        int curSmallestWebCost = Integer.MAX_VALUE;
        PriorityQueue<Integer[]> minCostPerNullNode = new PriorityQueue<>(Comparator.comparingInt(a -> a[1]));
        /* [0]->Nullified node index [1]->Current web's weight */
        int[][] curNodePerWeight = new int[n][n];
        ArrayList<PriorityQueue<Integer[]>> curPathPerNullNode = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            minCostPerNullNode.add(new Integer[]{i, 0});
            int _i = i;
            curPathPerNullNode.add(new PriorityQueue<>(Comparator.comparingInt(a -> a[2])));
            /* [0]->Target [1]->Node index [2]->Node weight */
            for (int j = 0; j < k; j++) {
                curNodePerWeight[i][_cR[k][0]] = 0;
                curPathPerNullNode.get(i).add(new Integer[]{_cR[k][1], _cR[k][0], 0});
            }
        }
        boolean isEmpty = false;
        while (!isEmpty) {
            Integer[] curWeb = minCostPerNullNode.poll();
            // RIGHT_NOW: Keep creating the Djikstra.
        }
        
        return 0;
    }
    
    static class NodeData {
        public PriorityQueue<Integer[]> curWeight = new PriorityQueue<>();
        public boolean hasNullified = false;
        public int nullifiedWeightIndex = -1;
    }
}
