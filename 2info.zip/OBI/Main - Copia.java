import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader b = new BufferedReader(new InputStreamReader(System.in));
        
        String[] curLine = b.readLine().split(" ");
        int n = Integer.parseInt(curLine[0]);
        int m = Integer.parseInt(curLine[1]);
        int k = Integer.parseInt(curLine[2]);
        
        ArrayList<ArrayList<Integer[]>> adjList = new ArrayList<>();
        for (int i = 0; i < n; i++)
            adjList.add(new ArrayList<>());
        
        int[][] routes = new int[m][2];
        for (int i = 0; i < m; i++) {
            curLine = b.readLine().split(" ");
            int u = Integer.parseInt(curLine[0])-1;
            int v = Integer.parseInt(curLine[1])-1;
            int w = Integer.parseInt(curLine[2]);
            routes[i] = new int[]{u, v};
            adjList.get(u).add(
                new Integer[]{v, w}
            );
            adjList.get(v).add(
                new Integer[]{u, w}
            );
        }
        
        int[][] courierRoutes = new int[k][2];
        for (int i = 0; i < k; i++) {
            curLine = b.readLine().split(" ");
            int u = Integer.parseInt(curLine[0])-1;
            int v = Integer.parseInt(curLine[1])-1;
            courierRoutes[i] = new int[]{u, v};
        }
        
        System.out.println(minCostCourierRoutes(n, adjList, k, courierRoutes));
    }
    
    public static int minCostCourierRoutes(int n, ArrayList<ArrayList<Integer[]>> adjList, int k, int[][] courierRoutes, int m, int[][] routes) {
        
        
        // RIGHT_NOW: Because nullification is based on PATH, and not NODE, you switch all the NULL NODE references to NULL PATH.
        
        
        int[][] _cR = courierRoutes;
        int curSmallestWebCost = Integer.MAX_VALUE;
        int curHardSmallestWebCost = Integer.MAX_VALUE;
        PriorityQueue<Integer[]> minCostPerNullNode = new PriorityQueue<>(Comparator.comparingInt(a -> a[1]));
        /* [0]->Nullified node index [1]->Current web's weight */
        ArrayList<ArrayList<ArrayList<Integer>>> weightPerNodePerNullNode = new ArrayList<>();
        /* [i]->Null node [i][k]->The courier index [i][k][j]->The node's weight for its origin*/
        ArrayList<PriorityQueue<Integer[]>> curPathPerNullNode = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            minCostPerNullNode.add(new Integer[]{i, Integer.MAX_VALUE});
            int _i = i;
            curPathPerNullNode.add(new PriorityQueue<>(Comparator.comparingInt(a -> a[2])));
            /* [0]->Target [1]->Node index [2]->Node weight */
            weightPerNodePerNullNode.add(new ArrayList<>());
            for (int j = 0; j < k; j++) {
                weightPerNodePerNullNode.get(i).add(new ArrayList<>());
                for (int z = 0; z < n; z++)
                    weightPerNodePerNullNode.get(i).get(j).add(Integer.MAX_VALUE);
                weightPerNodePerNullNode.get(i).get(j).set(_cR[j][0], 0);
                curPathPerNullNode.get(i).add(new Integer[]{j, _cR[j][0], 0});
            }
        }
        //boolean isEmpty = false;
        while (!minCostPerNullNode.isEmpty()) {
            Integer[] curWeb = minCostPerNullNode.poll();
            int cWebNullNode = curWeb[0];
            int cWebWeight = curWeb[1];

            PriorityQueue<Integer[]> cWebPathPerNullNodePQueue = curPathPerNullNode.get(cWebNullNode);
            Integer[] cPathNode = cWebPathPerNullNodePQueue.poll();
            int cPNCourier = cPathNode[0];
            int cPNNodeIndex = cPathNode[1];
            int cPNNodeWeight = cPathNode[2];
            //System.out.println("Neighbour checking");
            for (Integer[] neighbourNode : adjList.get(cPNNodeIndex)) {
                //System.out.println(String.format("%d %d %d", cPNNodeIndex, neighbourNode[0], _cR[cPNCourier][1]));
                int curNeighbourWeight = weightPerNodePerNullNode.get(cWebNullNode).get(cPNCourier).get(neighbourNode[0]);
                if (curNeighbourWeight > cPNNodeWeight+neighbourNode[1]) {
                    if (neighbourNode[0] == _cR[cPNCourier][1]) {
                        System.out.println(String.format("%d %d", cPNCourier, _cR[cPNCourier][0]));
                        if (cWebWeight != Integer.MAX_VALUE) {
                            if (curNeighbourWeight != Integer.MAX_VALUE) cWebWeight -= curNeighbourWeight;
                            cWebWeight += cPNNodeWeight+neighbourNode[1];
                        }else {
                            cWebWeight = cPNNodeWeight+neighbourNode[1];
                        }
                    }else cWebPathPerNullNodePQueue.add(new Integer[]{cPNCourier, neighbourNode[0], cPNNodeWeight+neighbourNode[1]});
                    weightPerNodePerNullNode.get(cWebNullNode).get(cPNCourier).set(neighbourNode[0], cPNNodeWeight+neighbourNode[1]);
                }
            }
            if (!cWebPathPerNullNodePQueue.isEmpty()) minCostPerNullNode.add(new Integer[]{cWebNullNode, cWebWeight});
            else {
                curSmallestWebCost = Math.min(curSmallestWebCost, cWebWeight);
                //System.out.println(String.format("%d %d", cWebNullNode, cWebWeight));
            }
        }
        
        return curSmallestWebCost;
    }
    
    /*static class NodeData {
        public PriorityQueue<Integer[]> curWeight = new PriorityQueue<>();
        public boolean hasNullified = false;
        public int nullifiedWeightIndex = -1;
    }*/
}
