import java.io.*;
import java.util.*;

class ShortestPathQueries {
    public static void main(String[] args) throws IOException {
        BufferedReader b = new BufferedReader(new InputStreamReader(System.in));
        String[] curLine = b.readLine().split(" ");
        int n = Integer.parseInt(curLine[0]);
        int m = Integer.parseInt(curLine[1]);
        int q = Integer.parseInt(curLine[2]);
        int[][] graph = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (i != j) graph[i][j] = -1;
                else graph[i][j] = 0;
            }
        }
        
        for (int i = 0; i < m; i++) {
            curLine = b.readLine().split(" ");
            int u = Integer.parseInt(curLine[0]);
            int v = Integer.parseInt(curLine[1]);
            int w = Integer.parseInt(curLine[2]);
            System.out.println(String.format("%d %d %d", u, v, w));
            graph[u-1][v-1] = Integer.parseInt(curLine[2]);
            graph[v-1][u-1] = Integer.parseInt(curLine[2]);
        }
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(graph[i][j] + " ");
            }
            System.out.println();
        }
        
        int[][] queries = new int[q][2];
        for (int i = 0; i < q; i++) {
            curLine = b.readLine().split(" ");
            int src = Integer.parseInt(curLine[0]);
            int dest = Integer.parseInt(curLine[1]);
            queries[i][0] = src-1;
            queries[i][1] = dest-1;
        }
        
        int[] queryAnswers = ShortestPathQueries.findShortestPathQueries(n, graph, q, queries);
        for (int i = 0; i < q; i++) {
            System.out.println(queryAnswers[i]);
        }
    }
    
    public static int[] findShortestPathQueries(int n, int[][] graph, int q, int[][] queries) {
        int[] queryAnswers = new int[q];
        
        for (int k = 0; k < n; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (graph[i][k] != -1 && graph[k][j] != 1) graph[i][j] = Math.min(graph[i][j], graph[i][k]+graph[k][j]);
                }
            }
        }
        
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(graph[i][j] + " ");
            }
            System.out.println();
        }
        
        for (int i = 0; i < q; i++) {
            queryAnswers[i] = graph[queries[i][0]][queries[i][1]];
        }
        return queryAnswers;
    }
}