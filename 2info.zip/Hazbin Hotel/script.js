function createLetterDiv(char) {
    const newLetterDiv = document.createElement("div");
    wordDiv.appendChild(newLetterDiv);
    newLetterDiv.classList.add("letterDiv");
    newLetterDiv.classList.add("letterDiv_"+char.toLowerCase());
}

function createLetterButton(index, char) {
    const newLetterBtn = document.createElement("div");
    const newLetterBtn_btn = document.createElement("button");
    newLetterBtn.classList.add("letterBtn");
    newLetterBtn.appendChild(newLetterBtn_btn);
    newLetterBtn_btn.innerText = char.toUpperCase();
    letterRows[index].appendChild(newLetterBtn);
    return newLetterBtn;
}

function win() {
    canPlay = false;
    victoryDiv.innerText = "Você ganhou!!";
    victoryDiv.style.visibility = "visible";
}

function lose() {
    canPlay = false;
    victoryDiv.innerText = "Você perdeu :(";
    victoryDiv.style.visibility = "visible";
}

function markLetter(char) {
    if (curWordMap.has(char.toLowerCase())) {
        curWordMap.delete(char.toLowerCase());
        hiddenLetters--;
        const letters = document.getElementsByClassName("letterDiv_"+char.toLowerCase());
        for (const letterDiv of letters) {
            letterDiv.innerText = char;
        }
        if (hiddenLetters == 0) {
            win();
        }
    }else {
        misses++;
        if (misses == maxMisses) {
            lose();
        }
    }
}

const root = document.getElementById("root");
const wordDiv = document.createElement("div");
const victoryDiv = document.createElement("div");
victoryDiv.innerText = "Você ganhou!!";
victoryDiv.style.visibility = "hidden";
wordDiv.id = "WordDiv";

let curWord = "ANGELDUST";
let misses = 0;
const maxMisses = 5;
let hiddenLetters = curWord.length;
let curWordMap = new Map();
let canPlay = true;
for (const curChar of curWord) {
    if (!curWordMap.has(curChar)) curWordMap.set(curChar.toLowerCase(), undefined);
    const newLetterDiv = createLetterDiv(curChar);
}

const letterBtnDiv = document.createElement("div");
letterBtnDiv.id = "LetterDiv";

const alphabet = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"];
let letterCounter = 0;
let firstRowCounter = 9;
let secondRowCounter = 17;
let letterIndex = 0;
let letterRows = [document.createElement("div"), document.createElement("div"), document.createElement("div")];
for (const row of letterRows) {
    letterBtnDiv.appendChild(row);
    row.classList.add("letterRow");
}
for (const curChar of alphabet) {
    const newLetterDiv = createLetterButton(letterIndex, curChar);
    letterCounter++;
    if (letterCounter == firstRowCounter || letterCounter == secondRowCounter) letterIndex++;
    newLetterDiv.children[0].addEventListener("click", () => {
        if (canPlay) markLetter(curChar);
    });
}

root.appendChild(wordDiv);
root.appendChild(letterBtnDiv);
root.appendChild(victoryDiv);