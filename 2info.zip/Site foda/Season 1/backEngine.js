x = document.getElementById("value").innerHTML+1;
document.getElementById("value").innerHTML = x;

header = document.getElementById('header');
header.innerHTML = x;
function tick() {

}
function doIt() {
    const x = document.getElementById("value").innerHTML+1;
    document.getElementById("value").innerHTML = x;

    const header = document.getElementByClass('header');
    header.innerHTML = 1000;
}