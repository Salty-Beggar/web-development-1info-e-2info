function startCock() {
    btn2.src = "troll2.jpg";
    contando = true;
    aaaaa = setInterval(() => {
        contador++;
        cont.innerText = contador;
    }, 0);
}

let aaaaa = 0;
let contando = false;
let contador = 0;

const body = document.body;
const btn = document.getElementById("btn");
const btn2 = document.getElementById("trollface");
const cont = document.getElementById("contador");

setTimeout(startCock, 3000);

btn.addEventListener("click", () => {
    if (contando) {
        contando = false;
        clearInterval(aaaaa);
    }
});


setInterval(changeBackgroundColor, 1);