let frutas = ["Morango", "Laranja", "Maçã"];

const root = document.getElementById('root')
const select = document.createElement("select");
for (const i of frutas) {
    const a = document.createElement("option");
    a.innerText = i;
    a.setAttribute("value", i);
    select.appendChild(a);
}
root.appendChild(select);

const bolas = document.createElement("div");
root.appendChild(bolas);
select.addEventListener("change", () => {
    bolas.innerText = select.children[select.selectedIndex].innerText;
})
