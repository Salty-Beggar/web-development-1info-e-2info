const root = document.getElementById('root')
const input = document.createElement("input");
const btn = document.createElement("button");
const list = document.createElement("ul");
const form = document.createElement("form");

root.id = "root";
root.appendChild(form);
root.appendChild(list);
form.appendChild(input);
form.appendChild(btn);

btn.innerText = "Adicionar";
btn.action = "submit";
form.addEventListener("submit", function(a) {
    a.preventDefault();
    const strValue = input.value.trim();
    input.value = "";
    if (strValue === "") return;
    const li = document.createElement("li");
    li.innerText = strValue;
    list.appendChild(li);
})