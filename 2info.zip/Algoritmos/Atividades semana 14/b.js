const prompt = require("prompt-sync")();

let n1 = Number(prompt("Início: "));
let n2 = Number(prompt("Final: "));
if (n1 % 2 == 1) n1++;
for (; n1 <= n2; n1 += 2) {
    console.log(i);
}