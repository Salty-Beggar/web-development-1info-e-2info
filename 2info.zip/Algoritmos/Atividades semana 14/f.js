const prompt = require("prompt-sync")();

const notaValores = [100, 50, 20, 10, 5, 2];
const notaQuantia = 6;
let notaQuantias = [0, 0, 0, 0, 0, 0];
let notaAtual = 0;
const troco = Number(prompt("Valor a ser pago? ")) - Number(prompt("Valor dado? "));
let trocoAtual = troco;
while (notaAtual != notaQuantia) {
    if (trocoAtual >= notaValores[notaAtual]) {
        notaQuantias[notaAtual]++;
        trocoAtual -= notaValores[notaAtual];
    }else notaAtual++;
}

console.log("Troco atual: "+troco.toString()+"R$");
for (let i = 0; i < notaQuantia; i++) console.log("Notas de "+notaValores[i].toString()+"R$: "+notaQuantias[i]);
console.log("E "+trocoAtual.toString()+"R$ em moedas.");