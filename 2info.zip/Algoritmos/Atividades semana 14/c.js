const prompt = require("prompt-sync")();

let n1 = Number(prompt("Número: "));
console.log((n1%2 == 0) ? n1/2 : n1*2);