const prompt = require("prompt-sync")();

let n = Number(prompt("Digite um núero: "))+1;
while (n % 5 != 0) {
    n++;
}
console.log("O número múltiplo de 5 acima do colocado é "+n.toString());