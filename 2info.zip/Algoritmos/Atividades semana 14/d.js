const prompt = require("prompt-sync")();

let n1 = Number(prompt("Número: "));
for (let i = 1; i <= n1; i++) {
    if (n1%i == 0) console.log(i);
}