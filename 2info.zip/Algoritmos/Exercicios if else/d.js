const prompt = require("prompt-sync")();
const n1 = Number(prompt("Número 1: "));
const n2 = Number(prompt("Número 2: "));
console.log((n1 != n2) ? Math.max(n1, n2) : "Os dois números são iguais.");