const prompt = require("prompt-sync")();
const n = (Number(prompt("Nota 1:"))+Number(prompt("Nota 2:"))+Number(prompt("Nota 3:")))/3;
if (n >= 7) {
	console.log("O aluno está aprovado");
}else {
	console.log("O aluno está reprovado");
}