const prompt = require("prompt-sync")();

const n = Number(prompt("Idade: "));
if (n <= 10) {
	console.log("R$ 30,00");
}else if (n <= 29) {
	console.log("R$ 60,00");
}else if (n <= 45) {
	console.log("R$ 120,00");
}else if (n <= 59) {
	console.log("R$ 150,00");
}else if (n <= 65) {
	console.log("R$ 250,00");
}else {
	console.log("R$ 400,00");
}