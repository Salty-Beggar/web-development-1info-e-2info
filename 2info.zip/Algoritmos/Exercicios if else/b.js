const prompt = require("prompt-sync")();
const n = Number(prompt("Número 1:"))+Number(prompt("Número 2:"));
if (n > 20) {
	console.log(n);
}