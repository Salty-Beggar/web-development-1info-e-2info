const prompt = require("prompt-sync")();
const n = Number(prompt("Número:"));
if (n > 20) {
	console.log(n);
}