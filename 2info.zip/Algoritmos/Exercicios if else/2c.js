const prompt = require("prompt-sync")();

console.log("Os ingredientes esgotarão em "+Math.ceil(Number(prompt("Quantia de ingredientes: "))/Number(prompt("Ingredientes por dia:"))).toString());