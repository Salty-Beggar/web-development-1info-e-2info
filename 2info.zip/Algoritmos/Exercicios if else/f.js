const prompt = require("prompt-sync")();
const n = Number(prompt("Idade: "));
if (n < 18) {
	console.log("Menor de idade");
}else if (n < 60) {
	console.log("Maior de idade");
}else {
	console.log("Idoso");
}