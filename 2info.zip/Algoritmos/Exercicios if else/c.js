const prompt = require("prompt-sync")();
const n = Number(prompt("Número 1:"));
if (n > 0) {
	console.log("Positivo");
}else if (n != 0) {
	console.log("Negativo");
}else {
	console.log("Zero");
}