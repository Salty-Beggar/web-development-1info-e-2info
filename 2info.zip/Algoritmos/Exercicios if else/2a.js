const prompt = require("prompt-sync")();

const salario = Number(prompt("Salário: "));
const aumento = Number(prompt("Porcento de aumento: "))/100;
console.log("Novo aumento"+(salario+salario*aumento).toString());