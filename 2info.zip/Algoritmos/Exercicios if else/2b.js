const prompt = require("prompt-sync")();

console.log((Number(prompt("Saldo: ")) >= Number(prompt("Preço do celular"))) ? "Pode comprar" : "Não pode comprar");