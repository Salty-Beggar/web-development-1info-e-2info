const prompt = require("prompt-sync")();
const n = Number(prompt("Idade: "));
if (n < 5) {
	console.log("Não se encaixa em nenhuma");
}else if (n < 8) {
	console.log("Infantil A");
}else if (n < 11) {
	console.log("Infantil B");
}else if (n < 14) {
	console.log("Juvenil A");
}else if (n < 18) {
	console.log("Juvenil B");
}else {
	console.log("Sênior");
}