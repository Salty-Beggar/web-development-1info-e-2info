const prompt = require("prompt-sync")();

console.log((Number(prompt("Largura: ")) == Number(prompt("Altura: "))) ? "É um quadrado" : "Não é um quadrado.");