const prompt = require("prompt-sync")();

const hTrabalhado = Number(prompt("Número de horas trabalhadas: "));
const hValor = Number(prompt("Valor por hora: "));
const salarioBruto = Math.min(hTrabalhado, 40)*hValor + Math.max(hTrabalhado-40, 0)*hValor*1.5;
console.log("O salário é "+salarioBruto.toString());