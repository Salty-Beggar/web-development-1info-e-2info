var preco = Number(prompt("Preço do produto:"));
console.log("O preço com desconto é "+(0.93*preco).toString()+". O preço com desconto também é "+(preco/100*93).toString());