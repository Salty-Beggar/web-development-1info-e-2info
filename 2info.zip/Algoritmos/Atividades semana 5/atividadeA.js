var valorCompra = Number(prompt("Qual o valor de compra?"));
var valorDado = Number(prompt("Qual o valor dado pelo cliente?"));
console.log("O troco é "+(valorDado-valorCompra).toString());