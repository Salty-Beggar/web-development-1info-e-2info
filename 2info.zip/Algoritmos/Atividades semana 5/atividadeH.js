var total = Number(prompt("Qual o número de hóspedes?"))*Number(prompt("Qual o valor por hóspede"))*Number(prompt("Por quantos dias os hóspedes ficarão?"));
console.log("O valor total dessa hospedagem será "+total.toString());
console.log("Com imposto de 3%, no entanto, será "+(total*1.03).toString());