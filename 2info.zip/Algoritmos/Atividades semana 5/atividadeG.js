var total = Number(prompt("Qual o número de hóspedes?"))*Number(prompt("Qual o valor por hóspede"));
console.log("O valor dessa diária será "+total.toString());