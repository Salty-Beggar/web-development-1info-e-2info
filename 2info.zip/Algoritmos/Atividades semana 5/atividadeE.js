var n = Number(prompt("Bote um número muito legal:"));
console.log("Os sucessores e antecessores do número muito legal, respectivamente, são "+(n+1).toString()+" e "+(n-1).toString());