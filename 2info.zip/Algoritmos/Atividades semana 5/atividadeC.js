var precoTotal = 0;
for (var i = 0; i < 5; i++) {
	precoTotal += Number(prompt("Qual é o preço do "+(i+1).toString()+"º produto?"));
}
console.log("O preço total é "+precoTotal.toString());