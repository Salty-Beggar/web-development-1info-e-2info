const prompt = require(prompt.sync);

class Player {
    constructor() {
        this.healthMax = 100;
        this.health = this.healthMax;
        this.manaMax = 100;
        this.mana = 0;

        this.inventoryMap = new Map();
    }
    alertInfo() {
        alert("Vida: "+this.health.toString()+"/"+this.healthMax.toString()+
            "\nMana: "+this.mana.toString()+"/"+this.manaMax.toString());
    }
}

class Chance {
    constructor(chance) {
        this.chance = chance;
    }
    try() {
        return Math.random() <= this.chance;
    }
}

class Item {
    constructor(player) {
        this.initializeName();
        player.inventoryMap.set(this.name, 0);
    }
    addToPlayer(player) {
        const newAmount = player.inventoryMap.get(this.name)+1;
        player.inventoryMap.set(this.name, newAmount);
    }
}

class Dagger extends Item {
    initializeName() {
        this.name = "dagger";
    }
}
    

function startGame() {
    const player = new Player();

    const dagger = new Dagger(player);
    
    while (true) {
        player.alertInfo();
        advanceTurn();
    }
}

function advanceTurn() {
    let nullTurn = true;
    let daggerChance = new Chance(1/5);

    if (daggerChance.try()) {
        nullTurn = false;
        alert("Você ganhou uma adaga");
    }

    if (nullTurn) {
        alert("Nada aconteceu.");
    }
}

startGame();