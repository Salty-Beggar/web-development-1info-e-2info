const prompt = require("prompt-sync")();

const voleiQuestions = ["Questão 1\nA - 5 jogadores\n-4 jogadores", "Questão 2 ", "Questão 3 ", "Questão 4 ", "Questão 5 "];
const voleiAnswers = ["A", "B", "C", "D", "A"];
const jogosQuestions = ["Questão 1 ", "Questão 2 ", "Questão 3 ", "Questão 4 ", "Questão 5 "];
const jogosAnswers = ["A", "B", "C", "D", "A"];

let theme = "";
do {
    let theme = prompt("Qual será o tema do quiz? (1- Vôlei 2- Jogos): ");
}while (theme != "1" || theme != "2");

const currentQuestions = (theme == "1") ? voleiQuestions : jogosQuestions;
const currentAnswers = (theme == "1") ? voleiAnswers : jogosAnswers;

let points = 0;
console.log("As respostas são A, B, C ou D. A questão será repetida até dar certo.");
for (let i = 0; i < 5; i++) {
    let curAnswer = "";
    do {
        let curAnswer = prompt(currentQuestions[i]);
    }while (curAnswer != "A" || curAnswer != "B" || curAnswer != "C" || curAnswer != "D");
    
    if (curAnswer = currentAnswers[i]) points++;
}
console.log("Você conseguiu "+points.toString()+" nesse quiz!");