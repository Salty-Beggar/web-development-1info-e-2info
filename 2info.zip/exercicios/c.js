const prompt = require("prompt-sync")();

let isCounting = true;
let intervalAmount = [0, 0, 0, 0];
while (isCounting) {
    const curNumber = Number(prompt("Número? "));
    if (curNumber < 0) isCounting = false;
    else if (curNumber < 26) intervalAmount[0]++;
    else if (curNumber < 51) intervalAmount[1]++;
    else if (curNumber < 76) intervalAmount[2]++;
    else if (curNumber < 101) intervalAmount[3]++;
}
console.log("Há "+intervalAmount[0]+" números entre 0 e 25, "+intervalAmount[1]+" entre 26 e 50"+intervalAmount[2]+" entre 51 e 75"+intervalAmount[3]+" entre 76 e 100");