const prompt = require("prompt-sync")();

let isCounting = true;
let votes = [0, 0, 0, 0, 0, 0];
while (isCounting) {
    const curNumber = Number(prompt("Voto: "));
    if (curNumber == 0) {
        isCounting = false;
    }else {
        votes[curNumber-1]++;
    }
}
console.log("Houve "+votes[0]+" votos para o candidato 1, "+votes[1]+" votos para o candidato 2, "+votes[2]+" votos para o candidato 3 e "+votes[3]+" votos para o candidato 4.");
console.log("Houve "+votes[4]+" votos nulos e "+votes[5]+" votos em branco");