const prompt = require("prompt-sync")();

const n = Number(prompt("Quantos números? "));
let i = 0;
while (i < n) {
    i++;
    const curNumber = Number(prompt("Número atual? "));
    let j = 0;
    let factorial = 1;
    while (j < curNumber) {
        factorial *= ++j;
    }
    console.log("O fatorial de "+curNumber+" é "+factorial);
}