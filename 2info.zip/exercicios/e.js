const prompt = require("prompt-sync")();

let i = 0;
let sum = 0;
while (i < 3) {
    const curNumber = Number(prompt("Número? "));
    sum += 1/curNumber;
    i++;
}
console.log("A média harmônica dos números é "+(3/sum));